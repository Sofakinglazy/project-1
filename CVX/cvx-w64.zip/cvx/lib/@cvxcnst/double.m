function x = double( v ) %#ok
cvx_throw( 'Disciplined convex programming error:\n   Constraints may not appear in if/then statements.' );

% Copyright 2005-2014 CVX Research, Inc. 
% See the file LICENSE.txt for full copyright information.
% The command 'cvx_where' will show where this file is located.
