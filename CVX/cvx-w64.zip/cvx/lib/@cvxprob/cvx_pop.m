function cvx_pop( p, do_warn )
evalin( 'caller', sprintf( 'cvx_pop(%d,%d,%d)', p.index_, p.id_, do_warn ) );

% Copyright 2005-2014 CVX Research, Inc.
% See the file LICENSE.txt for full copyright information.
% The command 'cvx_where' will show where this file is located.
