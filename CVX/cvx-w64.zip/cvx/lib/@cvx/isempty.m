function y = isempty(x)
y = ~all(x.size_);

